window.SITE_CONTENT = {
  "company": "United Technologies Systems Ltd.",
  "tagline": "Unites Construction Masters",
  "experience": "Since 2002",
  "phone": "0244295956",
  "whatsapp": "233244295956",
  "email": "kofikk611@gmail.com",
  "location": "Cantonments, Accra, Ghana",
  "services": [
    "Plaster Board Ceiling",
    "Wall Partitioning",
    "Acoustic Ceiling",
    "Suspended Ceiling",
    "Wall Skimming",
    "Raised Floor",
    "POP Ceiling",
    "Interior Decoration",
    "Painting",
    "Supply of Ceiling Materials"
  ],
  "intro": "Professional ceiling, interior finishing and painting services for homes, offices, commercial spaces and major projects.",
  "gallery": [
    {
      "src": "images/project-1.jpg",
      "title": "Completed Ceiling Project",
      "type": "Company Project"
    },
    {
      "src": "images/project-2.jpg",
      "title": "Suspended Ceiling Installation",
      "type": "Company Project"
    },
    {
      "src": "images/project-3.jpg",
      "title": "Decorative Ceiling",
      "type": "Company Project"
    },
    {
      "src": "images/project-4.jpg",
      "title": "Residential Ceiling Finish",
      "type": "Company Project"
    },
    {
      "src": "images/project-5.jpg",
      "title": "Modern Ceiling Detail",
      "type": "Company Project"
    },
    {
      "src": "images/project-6.jpg",
      "title": "Interior Ceiling Project",
      "type": "Company Project"
    },
    {
      "src": "images/project-7.jpg",
      "title": "Feature Ceiling",
      "type": "Company Project"
    },
    {
      "src": "images/project-8.jpg",
      "title": "Ceiling & Lighting",
      "type": "Company Project"
    },
    {
      "src": "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 1",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 2",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 3",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 4",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 5",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 6",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600607688969-a5bfcd646154?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 7",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600566753051-7b7f4b7c7f75?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 8",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 9",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 10",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 11",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1200&q=85&ixlib=rb-4.1.0",
      "title": "Ceiling Design Inspiration 12",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600210491892-03d54c0aaf87?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 13",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85&sat=-10",
      "title": "Ceiling Design Inspiration 14",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600607688960-e095ff83135c?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 15",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600573472591-ee6f7b4f2a1d?auto=format&fit=crop&w=1200&q=85",
      "title": "Ceiling Design Inspiration 16",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=85&flip=h",
      "title": "Ceiling Design Inspiration 17",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=85&flip=h",
      "title": "Ceiling Design Inspiration 18",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1200&q=85&flip=h",
      "title": "Ceiling Design Inspiration 19",
      "type": "Inspiration"
    },
    {
      "src": "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=85&flip=h",
      "title": "Ceiling Design Inspiration 20",
      "type": "Inspiration"
    }
  ]
};
